
const { Pool } = require('pg');

const pool = new Pool({
  user: 'YOUR_DB_USER',
  host: 'YOUR_DB_HOST',
  database: 'YOUR_DB_NAME',
  password: 'YOUR_DB_PASSWORD',
  port: 5432,
});

exports.syncExpenses = async (req, res) => {
  const { expenses } = req.body;

  try {
    for (const exp of expenses) {
      await pool.query(
        'INSERT INTO expenses(amount, created_at) VALUES($1, $2)',
        [exp.amount, exp.created_at]
      );
    }
    res.json({ message: 'Synced successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Sync failed' });
  }
};
